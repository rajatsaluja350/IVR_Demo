import os
import json
import azure.functions as func
from azure.eventgrid import EventGridEvent
from azure.eventgrid._helpers import _from_json
from azure.communication.callautomation.aio import CallAutomationClient

ACS_CONNECTION_STRING = os.getenv('ACS_CONNECTION_STRING')
CALLBACK_BASE_URL = os.getenv('CALLBACK_BASE_URL')

call_automation_client = CallAutomationClient.from_connection_string(ACS_CONNECTION_STRING)

async def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        events = req.get_json()
        # Event Grid may send a single event object or an array
        if isinstance(events, dict):
            events = [events]

        # Handle subscription validation
        if events and events[0].get('eventType') == 'Microsoft.EventGrid.SubscriptionValidationEvent':
            validation_code = events[0]['data']['validationCode']
            return func.HttpResponse(body=json.dumps({"validationResponse": validation_code}), status_code=200, mimetype='application/json')

        # Handle IncomingCall events
        for e in events:
            event = EventGridEvent.from_dict(e)
            if event.event_type == 'Microsoft.Communication.IncomingCall':
                data = event.data
                incoming_call_context = data['incomingCallContext']
                caller = data.get('from', {})
                if caller.get('kind') == 'phoneNumber':
                    caller_id = caller.get('phoneNumber', {}).get('value')
                else:
                    caller_id = caller.get('rawId')

                callback_url = f"{CALLBACK_BASE_URL}/api/callbacks?callerId={caller_id}"
                await call_automation_client.answer_call(
                    incoming_call_context=incoming_call_context,
                    callback_url=callback_url
                )
        return func.HttpResponse(status_code=200)
    except Exception as ex:
        return func.HttpResponse(str(ex), status_code=500)