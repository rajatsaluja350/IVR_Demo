
# Azure Functions – Python IVR (ACS Call Automation)

This is a **test IVR** that captures standardized order intake using **Azure Communication Services (ACS) Call Automation**.

## Features
- Handles **incoming PSTN calls** to an ACS phone number
- Uses **Event Grid** to deliver `Microsoft.Communication.IncomingCall` to `/api/events`
- Answers calls and registers **/api/callbacks** for mid-call events
- Prompts for: facility code (DTMF) → caller name → patient name → room number → facility type → special instructions
- **Repeat-back confirmation** and final summary

## Prerequisites
- An **Azure Communication Services** resource with a **phone number** capable of inbound calling (by country/number type)  
  See: https://learn.microsoft.com/azure/communication-services/quickstarts/telephony/get-phone-number
- Python 3.10+ and Azure Functions Core Tools

## Local settings
Copy `local.settings.sample.json` to `local.settings.json` and set values:

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "UseDevelopmentStorage=true",
    "FUNCTIONS_WORKER_RUNTIME": "python",
    "ACS_CONNECTION_STRING": "<your acs conn string>",
    "CALLBACK_BASE_URL": "https://<your-ngrok-or-app-url>",
    "FACILITY_DB_JSON": "{"BAYAUS": {"name": "Baylor Austin", "city": "Austin", "state": "TX"}}"
  }
}
```

## Run locally
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
func start
```
Then expose your local Functions host with **ngrok** and set `CALLBACK_BASE_URL` accordingly.

## Deploy to Azure (Zip deploy)
```bash
# in the project root
func azure functionapp publish <YourFunctionAppName>
```

## Event Grid subscription (IncomingCall → /api/events)
```bash
RESOURCE_ID=$(az resource show -g <rg> -n <acsName> --resource-type Microsoft.Communication/communicationServices --query id -o tsv)
FN_HOST=https://<YourFunctionAppName>.azurewebsites.net
FN_KEY=$(az functionapp function keys list -g <rg> -n <YourFunctionAppName> --function-name EventGridHandler --query default -o tsv)

az eventgrid event-subscription create   --name acs-incoming-call   --source-resource-id $RESOURCE_ID   --endpoint "$FN_HOST/api/events?code=$FN_KEY"   --event-delivery-schema eventgrid   --included-event-types Microsoft.Communication.IncomingCall
```

> **Note**: For production, secure `/api/callbacks` with JWT validation using Call Automation OpenID config and protect the Event Grid endpoint with Azure AD or validation handshake.

## References
- Recognize user input (DTMF/Speech/Choices): https://learn.microsoft.com/azure/communication-services/how-tos/call-automation/recognize-action
- Incoming call via Event Grid: https://learn.microsoft.com/azure/event-grid/communication-services-voice-video-events
- Webhook security: https://learn.microsoft.com/azure/communication-services/how-tos/call-automation/secure-webhook-endpoint
```
