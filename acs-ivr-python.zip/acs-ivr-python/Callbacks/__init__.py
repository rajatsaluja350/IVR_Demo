import os
import json
import urllib.parse
import azure.functions as func
from typing import List
from azure.core.messaging import CloudEvent
from azure.communication.callautomation.aio import CallAutomationClient
from azure.communication.callautomation import (
    PhoneNumberIdentifier,
    RecognizeInputType,
    TextSource
)
from shared.state import CALL_STATE

ACS_CONNECTION_STRING = os.getenv('ACS_CONNECTION_STRING')
FACILITY_DB_JSON = os.getenv('FACILITY_DB_JSON', '{}')
FACILITY_DB = json.loads(FACILITY_DB_JSON)

call_automation_client = CallAutomationClient.from_connection_string(ACS_CONNECTION_STRING)

async def _play_and_recognize_speech(call_connection_id: str, caller_id: str, text: str, context: str):
    play_source = TextSource(text=text, voice_name='en-US-ElizabethNeural')
    conn = call_automation_client.get_call_connection(call_connection_id)
    await conn.start_recognizing_media(
        input_type=RecognizeInputType.SPEECH,
        target_participant=PhoneNumberIdentifier(caller_id),
        end_silence_timeout=1,
        play_prompt=play_source,
        operation_context=context
    )

async def _recognize_dtmf(call_connection_id: str, caller_id: str, text: str, max_digits: int, context: str):
    play_source = TextSource(text=text, voice_name='en-US-ElizabethNeural')
    conn = call_automation_client.get_call_connection(call_connection_id)
    await conn.start_recognizing_media(
        input_type=RecognizeInputType.DTMF,
        target_participant=PhoneNumberIdentifier(caller_id),
        max_tones_to_collect=max_digits,
        inter_tone_timeout=5,
        play_prompt=play_source,
        operation_context=context
    )

async def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
        if isinstance(body, dict):
            events = [body]
        else:
            events = body

        caller_id = req.params.get('callerId')
        if caller_id and not caller_id.startswith('+') and caller_id.isdigit():
            caller_id = f"+{caller_id}"
        
        for e in events:
            event = CloudEvent.from_dict(e)
            etype = event.type
            data = event.data or {}
            call_connection_id = data.get('callConnectionId')
            if not call_connection_id:
                continue

            if etype == 'Microsoft.Communication.CallConnected':
                # Start IVR: facility code via DTMF
                CALL_STATE[call_connection_id] = {'step': 'facility_code'}
                await _recognize_dtmf(call_connection_id, caller_id,
                    'Welcome to Order Intake. Please enter your facility access code followed by the pound key.',
                    max_digits=6,
                    context='facility_code')
            elif etype == 'Microsoft.Communication.RecognizeCompleted':
                opctx = data.get('operationContext') or ''
                recog_type = data.get('recognitionType')
                state = CALL_STATE.get(call_connection_id, {'step': 'facility_code'})
                step = state.get('step')
                
                # Parse results
                speech_text = None
                digits = None
                if recog_type == 'speech':
                    speech = data.get('speechResult') or {}
                    speech_text = (speech.get('speech') or '').strip()
                elif recog_type == 'dtmf':
                    tones = data.get('dtmfResult') or data.get('collectTonesResult') or {}
                    # tones may be list of strings e.g., ['one','two'] or digits
                    t = tones.get('tones') if isinstance(tones, dict) else None
                    if isinstance(t, list):
                        map_tone = {
                            'zero':'0','one':'1','two':'2','three':'3','four':'4','five':'5','six':'6','seven':'7','eight':'8','nine':'9','pound':'#','asterisk':'*'
                        }
                        digits = ''.join(map_tone.get(x, '') for x in t)

                # State machine
                if step == 'facility_code':
                    code = digits or (speech_text or '').upper().replace(' ', '')
                    state['facility_code'] = code
                    # Lookup facility
                    fac = FACILITY_DB.get(code)
                    if fac:
                        state['facility_lookup'] = fac
                        state['step'] = 'facility_confirm'
                        await _play_and_recognize_speech(
                            call_connection_id, caller_id,
                            f"I heard {fac['name']} in {fac['city']} {fac['state']}. Say Confirm to continue or Cancel to re-enter.",
                            context='facility_confirm'
                        )
                    else:
                        await _recognize_dtmf(
                            call_connection_id, caller_id,
                            'I could not find that facility code. Please re-enter your 6 digit facility code followed by pound.',
                            max_digits=6,
                            context='facility_code')
                elif step == 'facility_confirm':
                    if speech_text and speech_text.lower().startswith('confirm'):
                        state['facility_confirmed'] = True
                        state['step'] = 'caller_name'
                        await _play_and_recognize_speech(
                            call_connection_id, caller_id,
                            'Please say your first and last name.',
                            context='caller_name')
                    else:
                        state['step'] = 'facility_code'
                        await _recognize_dtmf(
                            call_connection_id, caller_id,
                            'Okay, please re-enter your 6 digit facility code followed by pound.',
                            max_digits=6,
                            context='facility_code')
                elif step == 'caller_name':
                    state['caller_name'] = speech_text
                    state['step'] = 'patient_name'
                    await _play_and_recognize_speech(
                        call_connection_id, caller_id,
                        'Please say the patient's full name.',
                        context='patient_name')
                elif step == 'patient_name':
                    state['patient_name'] = speech_text
                    state['step'] = 'room_number'
                    await _play_and_recognize_speech(
                        call_connection_id, caller_id,
                        'Please say the patient's room number.',
                        context='room_number')
                elif step == 'room_number':
                    state['room_number'] = speech_text
                    state['step'] = 'facility_type'
                    await _play_and_recognize_speech(
                        call_connection_id, caller_id,
                        'Please say your facility type. For example, say mid pick needs.',
                        context='facility_type')
                elif step == 'facility_type':
                    state['facility_type'] = speech_text
                    state['step'] = 'special_instructions'
                    await _play_and_recognize_speech(
                        call_connection_id, caller_id,
                        'Any special instructions? You can say none if there are none.',
                        context='special_instructions')
                elif step == 'special_instructions':
                    state['special_instructions'] = speech_text
                    state['step'] = 'final_confirm'
                    fac = state.get('facility_lookup', {})
                    summary = (
                        f"You entered: Facility {fac.get('name','unknown')} in {fac.get('city','')}, "
                        f"Caller {state.get('caller_name','')}, Patient {state.get('patient_name','')} in room {state.get('room_number','')}, "
                        f"Facility type {state.get('facility_type','')}, Special instructions {state.get('special_instructions','none')}. "
                        "Say Confirm to submit or Cancel to restart."
                    )
                    await _play_and_recognize_speech(
                        call_connection_id, caller_id,
                        summary,
                        context='final_confirm'
                    )
                elif step == 'final_confirm':
                    if speech_text and speech_text.lower().startswith('confirm'):
                        state['final_confirmed'] = True
                        state['step'] = 'done'
                        # In a production app, persist to a database and enqueue for dispatch.
                        await _play_and_recognize_speech(
                            call_connection_id, caller_id,
                            'Thank you. Your order has been captured and is pending dispatch. Goodbye.',
                            context='goodbye')
                    else:
                        # Restart
                        state.clear()
                        state['step'] = 'facility_code'
                        await _recognize_dtmf(
                            call_connection_id, caller_id,
                            'Okay, let's start over. Please enter your 6 digit facility code followed by pound.',
                            max_digits=6,
                            context='facility_code')

            elif etype == 'Microsoft.Communication.RecognizeFailed':
                # Reprompt based on the last step
                state = CALL_STATE.get(call_connection_id, {'step': 'facility_code'})
                step = state.get('step')
                if step == 'facility_code':
                    await _recognize_dtmf(call_connection_id, caller_id,
                        'I did not get that. Please enter your 6 digit facility code followed by pound.',
                        max_digits=6,
                        context='facility_code')
                else:
                    await _play_and_recognize_speech(call_connection_id, caller_id,
                        'Sorry, I did not catch that. Please repeat.', context=step)

        return func.HttpResponse(status_code=200)
    except Exception as ex:
        return func.HttpResponse(str(ex), status_code=500)