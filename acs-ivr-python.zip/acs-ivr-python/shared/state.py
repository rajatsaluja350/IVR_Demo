# Simple in-memory call state for demo purposes only.
# In production, replace with durable storage (Cosmos DB/Redis/Table Storage).
from typing import Dict, Any

CALL_STATE: Dict[str, Dict[str, Any]] = {}

FIELDS = [
    'facility_code',
    'facility_confirmed',
    'caller_name',
    'patient_name',
    'room_number',
    'facility_type',
    'special_instructions',
    'final_confirmed'
]